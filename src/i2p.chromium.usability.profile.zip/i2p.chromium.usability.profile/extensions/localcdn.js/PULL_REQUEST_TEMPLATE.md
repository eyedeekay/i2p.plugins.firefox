### Please select only the development branch as destination for a pull request

### See CONTRIBUTING.md for more guidelines on how to make improvements

### For translations: LocalCDN is on [Weblate](https://hosted.weblate.org/projects/localcdn/localcdn/)
