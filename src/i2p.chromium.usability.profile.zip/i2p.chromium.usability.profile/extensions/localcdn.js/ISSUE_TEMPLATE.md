## Please read this text carefully(!)

* Only Firefox: Does the website work after you activate the HTML filter?

* Is there already an existing issue? (Search for the URL, e.g. "codeberg.org" or "localcdn.org")

* For the most common problems and solutions I have created an online tool. Please test the broken website there: https://www.localcdn.org/test/check

## If none of the points apply
* write the URL in the title
* one or two screenshots can be helpful

## Please delete this text(!)
## and describe the problem

Thank you for your understanding
