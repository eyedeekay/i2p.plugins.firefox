This browser profile is entirely composed of the work of Free Software developers.
The licenses for the sub-projects may be found in the extensions directories themselves.

i2p.chromium.usabilty.profile/extensions/i2pchrome.js/
i2p.chromium.usabilty.profile/extensions/jshelter.js/
i2p.chromium.usabilty.profile/extensions/localcdn.js/
i2p.chromium.usabilty.profile/extensions/ublock.js/