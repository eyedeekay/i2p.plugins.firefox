TODO:

Licensing work! This is probably mostly done, but I need to double-check it to make sure
the T&C are the same from all of these extensions are the same as for their Firefox versions
since I did the licensing review already. Since the license is included with the unpacked
extensions, we're almost certainly good.
